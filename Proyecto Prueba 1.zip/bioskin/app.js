/* ============================================================
   BIO SKIN — interacciones
   ============================================================ */
(function () {
  'use strict';

  /* ---------- NAV scroll ---------- */
  const nav = document.getElementById('nav');
  const onScroll = () => {
    if (window.scrollY > 30) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- Ticker ---------- */
  const tickerItems = ['Toxina Botulínica', 'Bioestimuladores', 'Pink Glow', 'Exosomas',
    'Microneedling', 'Revita-HA', 'Mesoterapia', 'Skinbooster', 'Ácido Hialurónico', 'Péptidos'];
  const ticker = document.getElementById('ticker');
  if (ticker) {
    const make = () => tickerItems.map(t =>
      `<span class="ticker-item"><span class="s"></span>${t}</span>`).join('');
    ticker.innerHTML = make() + make(); // duplicado para loop continuo
  }

  /* ---------- Imágenes (Pexels CDN) ---------- */
  const PX = (id, w) => `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&w=${w || 1100}`;
  const RU = (n) => `https://randomuser.me/api/portraits/women/${n}.jpg`;

  /* ---------- Tratamientos ---------- */
  const treatments = [
    { tag: 'Antiarrugas', name: 'Toxina Botulínica', img: 'tr-botox', px: 7582568,
      desc: 'Suaviza las líneas de expresión en frente, entrecejo y patas de gallo. Una mirada fresca, descansada y relajada.',
      chips: ['Frente', 'Entrecejo', 'Periocular'] },
    { tag: 'Firmeza', name: 'Bioestimuladores BCN', img: 'tr-bio', px: 3997391,
      desc: 'Cócteles de péptidos biomiméticos que estimulan tu propio colágeno para una piel más firme y elástica.',
      chips: ['Colágeno', 'Elasticidad'] },
    { tag: 'Luminosidad', name: 'Pink Glow', img: 'tr-glow', px: 5069432,
      desc: 'Hidratación profunda y efecto glow inmediato para una piel jugosa, luminosa y llena de vida.',
      chips: ['Hidratación', 'Glow'] },
    { tag: 'Regeneración', name: 'Exosomas + Microneedling', img: 'tr-exo', px: 4586713,
      desc: 'Regeneración celular avanzada: afina poros, atenúa marcas y devuelve calidad y textura a tu piel.',
      chips: ['Antiedad', 'Textura'] },
    { tag: 'Revitalización', name: 'Revita-HA', img: 'tr-revita', px: 3762879,
      desc: 'Cóctel revitalizante con ácido hialurónico que rehidrata y mejora la calidad de la piel desde dentro.',
      chips: ['Hidratación', 'Calidad'] },
    { tag: 'Nutrición', name: 'Mesoterapia Facial', img: 'tr-meso', px: 3985360,
      desc: 'Microinyecciones de activos, vitaminas y antioxidantes que nutren y aportan luminosidad a tu rostro.',
      chips: ['Vitaminas', 'Luminosidad'] },
  ];
  const grid = document.getElementById('treatGrid');
  if (grid) {
    grid.innerHTML = treatments.map((t, i) => `
      <article class="tcard reveal ${i % 3 === 1 ? 'd1' : i % 3 === 2 ? 'd2' : ''}">
        <div class="tc-img">
          <span class="tc-tag">${t.tag}</span>
          <image-slot id="${t.img}" src="${PX(t.px)}" placeholder="${t.name}" fit="cover"></image-slot>
        </div>
        <div class="tc-body">
          <h3>${t.name}</h3>
          <p class="tc-desc">${t.desc}</p>
          <div class="tc-benefits">${t.chips.map(c => `<span class="chip">${c}</span>`).join('')}</div>
          <a href="#contacto" class="tc-link">Consultar este tratamiento
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
          </a>
        </div>
      </article>`).join('');
  }

  /* ---------- Testimonios ---------- */
  const testis = [
    { q: 'Llevaba años con miedo a la toxina y aquí me explicaron todo con calma. El resultado es súper natural, nadie nota qué me hice, solo que me veo descansada.', nm: 'Camila R.', rl: 'Toxina botulínica', av: 'av-1', ru: 1 },
    { q: 'Mi piel estaba apagada y opaca. Después del Pink Glow la siento hidratada y con un brillo que no tenía hace años. Una experiencia impecable.', nm: 'Valentina M.', rl: 'Pink Glow', av: 'av-2', ru: 5 },
    { q: 'Profesionalismo total. Se nota que es enfermera: todo estéril, seguro y con un trato muy cercano. Volveré sin dudarlo.', nm: 'Francisca T.', rl: 'Bioestimuladores', av: 'av-3', ru: 26 },
  ];
  const star = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="m12 2 2.9 6.3 6.9.7-5.1 4.6 1.4 6.8L12 17.8 5.9 20.4l1.4-6.8L2.2 9l6.9-.7z"/></svg>`;
  const tg = document.getElementById('testiGrid');
  if (tg) {
    tg.innerHTML = testis.map((t, i) => `
      <div class="tquote reveal ${i === 1 ? 'd1' : i === 2 ? 'd2' : ''}">
        <div class="stars">${star.repeat(5)}</div>
        <p>“${t.q}”</p>
        <div class="who">
          <image-slot id="${t.av}" src="${RU(t.ru)}" shape="circle" placeholder="Foto"></image-slot>
          <div><div class="nm">${t.nm}</div><div class="rl">Paciente · ${t.rl}</div></div>
        </div>
      </div>`).join('');
  }

  /* ---------- FAQ ---------- */
  const faqs = [
    { q: '¿Los tratamientos duelen?', a: 'La mayoría son mínimamente molestos. Usamos anestesia tópica y técnicas suaves para que tu experiencia sea lo más cómoda posible.' },
    { q: '¿Cuándo veré resultados?', a: 'Depende del tratamiento: algunos como el Pink Glow dan un glow inmediato, mientras que la toxina botulínica se aprecia entre 3 y 7 días.' },
    { q: '¿Es seguro?', a: 'Sí. Todos los procedimientos los realiza una enfermera dermoestética titulada, con productos de grado médico y protocolos estériles de bioseguridad.' },
    { q: '¿Necesito tiempo de recuperación?', a: 'La mayoría de los tratamientos son ambulatorios y puedes retomar tu día. Te entregamos indicaciones de cuidado para las horas posteriores.' },
    { q: '¿Cómo sé qué tratamiento necesito?', a: 'No tienes que saberlo. En tu consulta inicial gratuita evaluamos tu piel y te recomendamos el plan ideal para tus objetivos.' },
  ];
  const fl = document.getElementById('faqList');
  if (fl) {
    fl.innerHTML = faqs.map(f => `
      <div class="faq-item">
        <button class="faq-q" type="button">${f.q}<span class="ic"></span></button>
        <div class="faq-a"><p>${f.a}</p></div>
      </div>`).join('');
    fl.addEventListener('click', e => {
      const btn = e.target.closest('.faq-q');
      if (!btn) return;
      const item = btn.parentElement;
      const open = item.classList.contains('open');
      fl.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!open) item.classList.add('open');
    });
  }

  /* ---------- Scroll reveal ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
  const observeReveals = () => document.querySelectorAll('.reveal:not(.in)').forEach(el => io.observe(el));
  observeReveals();
  // re-observe after dynamic injection
  setTimeout(observeReveals, 50);

  /* ---------- Count up ---------- */
  const countEls = document.querySelectorAll('[data-count]');
  const fmt = (n) => n >= 1000 ? n.toLocaleString('es-CL') : String(n);
  const cio = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (!e.isIntersecting) return;
      const el = e.target, target = +el.dataset.count, suf = el.dataset.suffix || '';
      const pre = suf === '%' ? '' : '+';
      let start = null, dur = 1400;
      const tick = (ts) => {
        if (!start) start = ts;
        const p = Math.min((ts - start) / dur, 1);
        const ease = 1 - Math.pow(1 - p, 3);
        el.textContent = (suf === '+' ? '+' : pre) + fmt(Math.round(target * ease)) + (suf === '%' ? '%' : '');
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cio.unobserve(el);
    });
  }, { threshold: 0.6 });
  countEls.forEach(el => cio.observe(el));

  /* ---------- Before / After slider ---------- */
  const stage = document.getElementById('baStage');
  if (stage) {
    const after = document.getElementById('baAfter');
    const handle = document.getElementById('baHandle');
    let dragging = false;
    const setPos = (clientX) => {
      const r = stage.getBoundingClientRect();
      let p = ((clientX - r.left) / r.width) * 100;
      p = Math.max(2, Math.min(98, p));
      after.style.clipPath = `inset(0 0 0 ${p}%)`;
      handle.style.left = p + '%';
    };
    const down = (e) => { dragging = true; setPos((e.touches ? e.touches[0] : e).clientX); };
    const move = (e) => { if (dragging) setPos((e.touches ? e.touches[0] : e).clientX); };
    const up = () => { dragging = false; };
    stage.addEventListener('mousedown', down);
    stage.addEventListener('touchstart', down, { passive: true });
    window.addEventListener('mousemove', move);
    window.addEventListener('touchmove', move, { passive: true });
    window.addEventListener('mouseup', up);
    window.addEventListener('touchend', up);
  }

  /* ---------- Forms ---------- */
  function handleLead(form, onSuccess) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const inputs = form.querySelectorAll('input[required]');
      let ok = true;
      inputs.forEach(i => {
        if (!i.value.trim()) { ok = false; i.style.borderColor = '#e0617a'; }
        else i.style.borderColor = '';
      });
      if (!ok) return;
      onSuccess(new FormData(form));
    });
  }

  const leadForm = document.getElementById('leadForm');
  if (leadForm) {
    handleLead(leadForm, (data) => {
      const name = (data.get('name') || '').trim().split(' ')[0] || 'bella';
      document.getElementById('successName').textContent = name;
      document.getElementById('leadForm').style.display = 'none';
      document.getElementById('leadSuccess').classList.add('show');
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    handleLead(contactForm, () => {
      const note = document.getElementById('contactNote');
      contactForm.querySelectorAll('input,textarea,button[type=submit]').forEach(el => el.disabled = true);
      contactForm.querySelector('button[type=submit]').innerHTML = '¡Solicitud enviada! ✓';
      note.textContent = '¡Gracias! Te contactaremos por WhatsApp muy pronto.';
      note.style.color = '#22b85a';
    });
  }

  /* ---------- Mobile menu (scroll to contacto) ---------- */
  const menuBtn = document.getElementById('menuBtn');
  if (menuBtn) menuBtn.addEventListener('click', () => {
    window.location.hash = '#contacto';
  });

})();
