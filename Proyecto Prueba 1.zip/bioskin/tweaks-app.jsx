/* global React, ReactDOM, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakColor, TweakSelect, TweakToggle */
const { useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "glow",
  "brand": ["#2C6CB0", "#4FA3EA", "#46C6CD"],
  "headline": "Tu piel, en su mejor versión",
  "glow": true
}/*EDITMODE-END*/;

const HEADLINES = {
  "Tu piel, en su mejor versión": ["Tu piel, en su", "mejor versión"],
  "Rejuvenece de forma natural": ["Rejuvenece de", "forma natural"],
  "La ciencia de verte bien": ["La ciencia de", "verte bien"],
  "Belleza con criterio clínico": ["Belleza con", "criterio clínico"],
};

function BioTweaks() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffect(() => {
    document.body.dataset.theme = t.theme;
  }, [t.theme]);

  useEffect(() => {
    const [brand, bright, aqua] = t.brand;
    const root = document.body.style;
    root.setProperty('--brand', brand);
    root.setProperty('--brand-bright', bright);
    root.setProperty('--aqua', aqua);
    // tono suave del aqua
    root.setProperty('--aqua-soft', aqua);
  }, [t.brand]);

  useEffect(() => {
    const el = document.getElementById('heroTitle');
    if (!el) return;
    const parts = HEADLINES[t.headline] || HEADLINES["Tu piel, en su mejor versión"];
    el.innerHTML = `${parts[0]}<br><em>${parts[1]}</em>`;
  }, [t.headline]);

  useEffect(() => {
    document.body.classList.toggle('no-glow', !t.glow);
  }, [t.glow]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Estilo visual" />
      <TweakRadio
        label="Tema"
        value={t.theme}
        options={[{ value: 'glow', label: 'Bio-Glow' }, { value: 'claro', label: 'Claro' }, { value: 'lujo', label: 'Lujo' }]}
        onChange={(v) => setTweak('theme', v)}
      />
      <TweakColor
        label="Color de marca"
        value={t.brand}
        options={[
          ['#2C6CB0', '#4FA3EA', '#46C6CD'],
          ['#1E8E9E', '#37C0CB', '#7FE0D6'],
          ['#5B5BD6', '#8A7BF0', '#46C6CD'],
          ['#C2569A', '#E27BB0', '#5BD0D6'],
        ]}
        onChange={(v) => setTweak('brand', v)}
      />
      <TweakToggle label="Resplandor animado" value={t.glow} onChange={(v) => setTweak('glow', v)} />

      <TweakSection label="Contenido" />
      <TweakSelect
        label="Titular del hero"
        value={t.headline}
        options={Object.keys(HEADLINES)}
        onChange={(v) => setTweak('headline', v)}
      />
    </TweaksPanel>
  );
}

ReactDOM.createRoot(document.getElementById('tweaks-root')).render(<BioTweaks />);
